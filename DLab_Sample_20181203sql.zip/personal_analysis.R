rm(list=ls())
setwd("C:/Users/DAL/Desktop/Data/DLab_Sample_20181203sql")
library(data.table)
library(bit64)
library(ggmap)
library(dplyr)
library(ggplot2)
library(cluster)
library(NbClust)
library(kohonen)
library(ggplot2)
library(gridExtra)
library(scales)
set.seed(99)
library(randomForest)
library(party)
library(missForest)


total<-data.frame(fread("total.txt",sep="\t"))
member<-data.frame(fread("member.txt",sep="\t"))


##��Ÿ ���� 
total<-total[total$CATEGORY!="��Ÿ",]
total$CATEGORY<-ifelse(total$APPROVAL_PRICE_INOUT>0,"�Ա�",total$CATEGORY)
totalSob<-total[total$APPROVAL_PRICE_INOUT<0&total$CATEGORY!="����",]
totalIncome<-total[total$APPROVAL_PRICE_INOUT>=0,]
totalSave<-total[total$APPROVAL_PRICE_INOUT<0&total$CATEGORY=="����",]

#���κ� �м� 
unique_card <- unique(as.data.table(totalSob[, c("key", "COMPANY_NAME")]))

personal<-data.frame(unique_card[,.N, by = "key"])
personal<-merge(personal,member[,c("key","gen","GENDER")],by="key")
personal$totalSob_price<-c()

personal$totalSob_price<-tapply(totalSob$CARD_APPROVAL_REAL_PRICE,totalSob$key,function(x){sum(x,na.rm=T)})


personal$volume<-tapply(totalSob$SMS_ID,totalSob$key,function(x){length(x)})
personal$maxCat1<-c()
personal$maxCat2<-c()
personal$maxCat3<-c()
personal$maxCat4<-c()
personal$maxCat5<-c()

personal[,c("maxCat1","maxCat2","maxCat3","maxCat4","maxCat5")]<-matrix(unlist(tapply(totalSob$NEWCAT,totalSob$key,function(x){names(sort(table(x),decreasing=T)[1:5])})),ncol=5,byrow=T)

temp<-totalSob%>%
  group_by(key)%>%
  summarise(start=min(SMS_REGISTRATION_MONTH),late=max(SMS_REGISTRATION_MONTH))
temp$period<-temp$late-temp$start
temp$period<-ifelse(temp$period>10,temp$period-87,temp$period+1)
personal<-merge(personal,temp[,c("key","start","late","period")],by="key",all.x=T)
personal$maxCat<-ifelse(personal$maxCat1=="��Ÿ",personal$maxCat2,personal$maxCat1)
personal$Y<-ifelse(personal$late==201811,0,1)
personal[is.na(personal)]<-99


# for(i in 1:10){
#   samp<-sample(1:19507,size=15000)
#   train<-personal[samp,]
#   test<-personal[-samp,]
#   model<-ctree(Y~N+gen+GENDER+totalSob_price+as.numeric(maxCat1)+as.numeric(maxCat2)+as.numeric(maxCat3)+start+mon_spend+avg_volume,data=train)
#   pred<-predict(model,test[,-16])
#   temp<-matrix(table(round(pred,0),test$Y))
#   print(table(test$Y))
#   print(sum(temp[c(1,4),1])/sum(temp))
# }
# plot(model)


temp<-totalSob%>%
  group_by(key)%>%
  summarise(sum(APPROVAL_PRICE_INOUT,na.rm=T))
personal<-merge(personal,temp,by="key")

personal$mon_spend<-round(personal$totalSob_price/personal$period,0)
personal$avg_volume<-personal$volume/personal$period

Cat<-totalSob%>%
  group_by(key,NEWCAT)%>%
  summarise(spend = sum(CARD_APPROVAL_REAL_PRICE))

Cat<-merge(Cat,personal[,c("key","period")],by="key",all.x=T)
Cat$mon_spend<-round(Cat$spend/Cat$period,0)



Month<-totalSob%>%
  group_by(key,SMS_REGISTRATION_MONTH)%>%
  summarise(spend_all = sum(CARD_APPROVAL_REAL_PRICE,na.rm=T),Juya = ifelse(sum(Juya)>0,1,0))
##Juya 1 �ְ��Һ� , 0 �߰��Һ� 
Month<-Month[is.na(Month$key)==F,]

Month<-merge(Month,personal[,c("key","period")],by="key",all.x=T)


MonCat<-totalSob%>%
  group_by(key,SMS_REGISTRATION_MONTH,NEWCAT)%>%
  summarise(spend=sum(CARD_APPROVAL_REAL_PRICE))%>%
  mutate(rank=rank(-spend,ties.method="first"))

MonCat_rank<-Month
MonCat_rank<-left_join(MonCat_rank,member[,c("key","GENDER",'gen',"age")],by="key")

temp<-totalSob%>%
  group_by(key,SMS_REGISTRATION_MONTH)%>%
  summarise(volume =n() )

MonCat_rank<-left_join(MonCat_rank,temp,by=c("key","SMS_REGISTRATION_MONTH"))

unique_card <- unique(as.data.table(totalSob[, c("key","SMS_REGISTRATION_MONTH", "COMPANY_NAME")]))
temp<-data.frame(unique_card[,.N,by=c("key","SMS_REGISTRATION_MONTH")])
MonCat_rank<-left_join(MonCat_rank,temp,by=c("key","SMS_REGISTRATION_MONTH"))




##ī�װ����� ��� �ݾ� 



# for( i in 1:15){
#   MonCat_rank<-left_join(MonCat_rank,temp[as.numeric(temp$CATEGORYN)==i,c(1,2,4)],by=c("key","SMS_REGISTRATION_MONTH"))
# }
# 
#   colnames(MonCat_rank)[11:25]<-c("Cat01","Cat02","Cat03","Cat04","Cat05","Cat06",
#                                   "Cat07","Cat08","Cat09","Cat010","Cat11","Cat12",
#                                   "Cat13","Cat14","Cat15")
# MonCat_rank[is.na(MonCat_rank)]<-0
# 


##��ȣ�ϴ� ī�װ��� �� ����
for(i in 1:5){
  MonCat_rank<-left_join(MonCat_rank,MonCat[as.numeric(MonCat$rank)==i,1:3],by=c("key","SMS_REGISTRATION_MONTH"))
}

colnames(MonCat_rank)[11:15]<-c("rank1","rank2","rank3","rank4","rank5")
MonCat_rank[is.na(MonCat_rank)]<-99

for(i in 1:5){
  MonCat_rank<-left_join(MonCat_rank,MonCat[as.numeric(MonCat$rank)==i,c(1,2,4)],by=c("key","SMS_REGISTRATION_MONTH"))
}

colnames(MonCat_rank)[16:20]<-c("spend1","spend2","spend3","spend4","spend5")
MonCat_rank[is.na(MonCat_rank)]<-0

MonCat_rank$rate1<-MonCat_rank$spend1/MonCat_rank$spend_all
MonCat_rank$rate2<-MonCat_rank$spend2/MonCat_rank$spend_all
MonCat_rank$rate3<-MonCat_rank$spend3/MonCat_rank$spend_all
MonCat_rank$rate4<-MonCat_rank$spend4/MonCat_rank$spend_all
MonCat_rank$rate5<-MonCat_rank$spend5/MonCat_rank$spend_all

##�׸� �ݾ� 
catprice<-totalSob%>%
  group_by(key,SMS_REGISTRATION_MONTH,NEWCAT)%>%
  summarise(CatPrice=sum(CARD_APPROVAL_REAL_PRICE))

table(catprice$NEWCAT)
for(i in c(1:7,11:18)){
  temp<-catprice[catprice$NEWCAT==i,]
  MonCat_rank<-left_join(MonCat_rank,temp[,c(1,2,4)],by=c("key","SMS_REGISTRATION_MONTH"))
}

colnames(MonCat_rank)[26:40]<-paste("Catprice",c(1:7,11:18),sep="")
MonCat_rank[is.na(MonCat_rank)]<-0


bx<-boxplot.stats(MonCat_rank$spend_all)
boxplot.stats(bx$out)
##�׻� 3555816 �̻� �Һ� �ϴ� �ΰ��� 
tem<-totalSob%>%
  group_by(key,SMS_REGISTRATION_MONTH)%>%
  summarise(Spend_all = sum(CARD_APPROVAL_REAL_PRICE))%>%
  mutate(rich=ifelse(Spend_all>3762982,1,0))
tem2<-tem%>%
  group_by(key)%>%
  mutate(countrich=sum(rich))
MonCat_rank<-left_join(MonCat_rank,tem2[,c("key","SMS_REGISTRATION_MONTH","countrich")],by=c("key","SMS_REGISTRATION_MONTH"))
MonCat_rank<-MonCat_rank[MonCat_rank$period!=MonCat_rank$countrich,]



MonCat_rank[,c("rank1")]<-as.numeric(MonCat_rank[,c("rank1")])
MonCat_rank[,c("rank2")]<-as.numeric(MonCat_rank[,c("rank2")])
MonCat_rank[,c("rank3")]<-as.numeric(MonCat_rank[,c("rank3")])
MonCat_rank[,c("rank4")]<-as.numeric(MonCat_rank[,c("rank4")])
MonCat_rank[,c("rank5")]<-as.numeric(MonCat_rank[,c("rank5")])


## ���� ����ȭ 
boxplot.stats(MonCat_rank$period) ## 7,12,13 
boxplot.stats(MonCat_rank$volume) ## 10, 29 ,53 max=117 , out ���� 2534�� 
boxplot.stats(MonCat_rank$rate1) ## 0.3368614 0.4549301 0.6521686
boxplot.stats(MonCat_rank[MonCat_rank$rate2!=99,]$rate2) ## 0.1446874  0.2021055  0.2577131  max = 0.4270833
boxplot.stats(MonCat_rank$N) ## 1 2 3  max=6 

MonCat_rank$periodc<-ifelse(MonCat_rank$period<7,1,ifelse(MonCat_rank$period<12,2,3))
MonCat_rank$volumec<-ifelse(MonCat_rank$volume<11,1,ifelse(MonCat_rank$volume<30,2,ifelse(MonCat_rank$volume<56,3,ifelse(MonCat_rank$volume<123,4,5))))
MonCat_rank$rate1c<-ifelse(MonCat_rank$rate1<0.148147,1,ifelse(MonCat_rank$rate1<0.371786,2,ifelse(MonCat_rank$rate1<0.4862151,3,ifelse(MonCat_rank$rate1<0.669514,4,ifelse(MonCat_rank$rate1<=1,5,99)))))
MonCat_rank$rate2c<-ifelse(MonCat_rank$rate2<0.1531404,1,ifelse(MonCat_rank$rate2<0.2180190,2,ifelse(MonCat_rank$rate2<0.2771100,3,ifelse(MonCat_rank$rate2<0.4630319,4,5))))
MonCat_rank$Ncardc<-ifelse(MonCat_rank$N<=1,1,ifelse(MonCat_rank$N<=2,2,ifelse(MonCat_rank$N<=3,3,ifelse(MonCat_rank$N<6,4,5))))
MonCat_rank<-left_join(MonCat_rank,personal[,c("key","Y")],by="key")


## �漺���� ���漺���� 
# temp<-MonCat%>%
#   group_by(key)%>%
#   summarise(period=length(unique(SMS_REGISTRATION_MONTH)),max=max(SMS_REGISTRATION_MONTH))
# temp2<-temp[temp$max!=201811,]


## �� ����ϴ� ���� �� ����ϴ°��� ( �������͸� ���� / ���� ������ �Ѱ��� /���űݾ��� �Ѱ��� ) 
# temp<-MonCat_rank%>%
#   group_by(key)%>%
#   select(key,SMS_REGISTRATION_MONTH,spend1,spend2,spend3,rate1,rate2,rate3)%>%
#   mutate(length(unique(spend1)))


MonCat_rank$mono<-5
MonCat_rank$mono<-ifelse(MonCat_rank$rate1!=0&MonCat_rank$rate2==0,1,MonCat_rank$mono)
MonCat_rank$mono<-ifelse(MonCat_rank$rate1!=0&MonCat_rank$rate2!=0&MonCat_rank$rate3==0,2,MonCat_rank$mono)
MonCat_rank$mono<-ifelse(MonCat_rank$rate1!=0&MonCat_rank$rate2!=0&MonCat_rank$rate3!=0&MonCat_rank$rate4==0,3,MonCat_rank$mono)
MonCat_rank$mono<-ifelse(MonCat_rank$rate1!=0&MonCat_rank$rate2!=0&MonCat_rank$rate3!=0&MonCat_rank$rate4!=0&MonCat_rank$rate5==0,4,MonCat_rank$mono)

MonCat_rank$CAT<-ifelse(MonCat_rank$rank1<10,1,10)
MonCat_rank$spendc<-MonCat_rank$spend_all
MonCat_rank$spendc<-ifelse(MonCat_rank$spendc<309195,1,
                           ifelse(MonCat_rank$spendc<804870.5,2,
                                  ifelse(MonCat_rank$spendc<1655558,3,
                                         ifelse(MonCat_rank$spendc<3675084,4,
                                                ifelse(MonCat_rank$spendc<4281326,5,
                                                       ifelse(MonCat_rank$spendc<5268956,6,
                                                              ifelse(MonCat_rank$spendc<7738345,7,
                                                                     ifelse(MonCat_rank$spendc<12916539,8,9))))))))
## ��� ī�װ��� ���� ���� ����ȭ 
for(i in 26:40){
  bx<-boxplot.stats(MonCat_rank[MonCat_rank[,i]!=0,i])$stats
  MonCat_rank[,i]<-ifelse(MonCat_rank[,i]==0,0,
                          ifelse(MonCat_rank[,i]<bx[2],1,
                                 ifelse(MonCat_rank[,i]<bx[3],2,
                                        ifelse(MonCat_rank[,i]<bx[4],3,
                                               ifelse(MonCat_rank[,i]<bx[5],4,5)))))
  
}

MonCat_rank<-left_join(MonCat_rank,personal[c("key","start","late")],by="key")
MonCat_rank$exitdate<-ifelse(MonCat_rank$SMS_REGISTRATION_MONTH==MonCat_rank$late&MonCat_rank$late!=201811,MonCat_rank$SMS_REGISTRATION_MONTH,0)

#pca
MonCat_pc<-MonCat_rank

pc1<-prcomp(scale(MonCat_pc[,c("Juya","volume","N","rank1","rank2","rank3","rank4","rank5","rate1c","rate2c","mono","CAT","spendc")]))
plot(pc1,type="l",main="PCA Scree plot",sub="Scree plot")
pc1$rotation
pcvariable<-data.frame(pc1$x[,1:6])
MonCat_pc<-cbind(MonCat_pc,pcvariable)
summary(pc1)

# pc2<-prcomp(scale(MonCat_rank[,c(4,6,7,11:20,26:46,48:50)]))
# plot(pc2,type="l",main="PCA Scree plot",sub="Scree plot")
# 
# pc2$rotation
# pcvariable<-data.frame(pc2$x[,1:5])
# MonCat_pc<-cbind(MonCat_pc,pcvariable)


wss<-0
for(i in 1:25){
  wss[i]<-kmeans(MonCat_pc[,c("PC1","PC2","PC3","PC4","PC5","PC6")],centers=i)$tot.withinss
}
plot(1:25,wss,type="b",xlab="#of clusters",ylab="Within group ss ",main="Determine # of Clusters")
#cluster �� 15�� ������ �����ѵ�

MonCat_pc$som<-som(scale(MonCat_pc[,c("PC1","PC2","PC3","PC4","PC5","PC6")]),somgrid(3,5,"rectangular"))$unit.classif
MonCat_pc$km<-kmeans(scale(MonCat_pc[,c("PC1","PC2","PC3","PC4","PC5","PC6")]),centers = 15)$cluster
som<-som(scale(MonCat_pc[,c("PC1","PC2","PC3","PC4","PC5","PC6")]),somgrid(3,5,"rectangular"))
km<-kmeans(scale(MonCat_pc[,c("PC1","PC2","PC3","PC4","PC5","PC6")]),centers = 15)


bet<-MonCat_pc[,c(54:59,61)]%>%
  group_by(km)%>%
  summarise(mean1=mean(PC1),mean2=mean(PC2),mean3=mean(PC3),mean4=mean(PC4),mean5=mean(PC5),mean6=mean(PC6),n=n())

mtotal<-apply(MonCat_pc[,c(54:59)],2,mean)

bss<-0
for(i in 1:15){
  bss<-sum(bss,as.numeric(sum((bet[i,2:7]-mtotal[1:6])^2)*bet[i,8]))
}
bss
ss<-0
for(i in 1:nrow(MonCat_pc)){
  ss<-sum(ss,sum((MonCat_pc[i,54:59]-mtotal[1:6])^2))
}

bss/ss

bet<-MonCat_pc[,c(54:59,60)]%>%
  group_by(som)%>%
  summarise(mean1=mean(PC1),mean2=mean(PC2),mean3=mean(PC3),mean4=mean(PC4),mean5=mean(PC5),mean6=mean(PC6),n=n())

mtotal<-apply(MonCat_pc[,c(54:59)],2,mean)

bss<-0
for(i in 1:15){
  bss<-sum(bss,as.numeric(sum((bet[i,2:7]-mtotal[1:6])^2)*bet[i,8]))
}

bss/ss

##sum of square �� � ���� ����� ���ΰ�? 





MonCat_pc$Newsom<-MonCat_pc$som



##SOM �� 
for(i in 1:15){
  gg<-ggplot(MonCat_pc[MonCat_pc$Newsom==i,],aes(x=rank1))
  print(gg+geom_histogram())
}

prop.table(table(MonCat_pc$rank1,MonCat_pc$Newsom),margin = 2)
table(MonCat_pc$rank1,MonCat_pc$Newsom)


table(MonCat_pc$som)
table(MonCat_pc$Newsom)
sp<-tapply(MonCat_pc$spend_all,MonCat_pc$Newsom,mean)#
spc<-tapply(MonCat_pc$spendc,MonCat_pc$Newsom,mean)#
rat1<-tapply(MonCat_pc$rate1,MonCat_pc$Newsom,mean)#
jy<-table(MonCat_pc$Juya,MonCat_pc$Newsom)#
mon<-tapply(MonCat_pc$mono,MonCat_pc$som,mean)
CAT<-table(MonCat_pc$CAT,MonCat_pc$Newsom)#
mon<-table(MonCat_pc$mono,MonCat_pc$Newsom)#
tapply(MonCat_pc$volumec,MonCat_pc$som,mean)
tapply(MonCat_pc$periodc,MonCat_pc$som,mean)
tapply(MonCat_pc$rank1,MonCat_pc$som,table)


gen<-table(MonCat_pc$gen,MonCat_pc$Newsom)
Gender<-table(MonCat_pc$GENDER,MonCat_pc$Newsom)
plot(spc,main="�Һ� �ݾ׺� ���",xlab="Cluster",ylab="�Һ�ݾ�",col=round(spc,0),type="p",pch=as.character(order(rat1)))

plot(rat1,main="�ֺ� ���� �׸� ����",xlab="Cluster",ylab="���� ����",pch=as.character(order(rat1)))

plot(x=1:nrow(MonCat_pc[MonCat_pc$Newsom==3,]),y=MonCat_pc[MonCat_pc$Newsom==3,]$spend_all,ylim=c(0,10000000))
points(MonCat_pc[MonCat_pc$key==11178&MonCat_pc$SMS_REGISTRATION_MONTH==201711,"spend_all"],col="red")
plot(density(MonCat_pc[MonCat_pc$Newsom==3,"spend_all"]),xlim=c(0,2500000),main="Density Function",xlab="Spend_all")
abline(v=50000,col="red")
ggplot(MonCat_pc[MonCat_pc$Newsom==3,],aes(x=spend_all))+geom_density()+xlim(0,750000)+geom_vline(aes(xintercept=50000),color="red")+ggtitle("�Һ� ���� ����")


hist(MonCat_pc[MonCat_pc$Newsom==3,"rank1"],col=ifelse(MonCat_pc[MonCat_pc$Newsom==3,"rank1"]==5,2,3),xlim=c(0,20),breaks=13)
ggplot(MonCat_pc[MonCat_pc$Newsom==3,],aes(x="",fill=rank1))+geom_bar(width = 1)+coord_polar(theta="y",start=0)+ggtitle(" �ֺ� ��ȣ �׸�")+labs(fill="�ֺ� ��ȣ �׸�")
temp<-MonCat_pc%>%
  filter(MonCat_pc$Newsom==3)%>%
  group_by(rank1)%>%
  summarise(n=n())%>%
  mutate(Cat=ifelse(rank1<10,"�ʼ�","����"))
ggplot(temp,aes(x="",y=n,fill=ifelse(rank1==4,1,0)))+
  geom_bar(stat="identity",width=1)+coord_polar(theta="y",start=0)+ggtitle("�ֺ� ��ȣ �׸�")

ggplot(MonCat_pc[MonCat_pc$Newsom==3,],aes(x=rate1c))+geom_bar(width = )

table(MonCat_pc[MonCat_pc$Newsom==3,"mono"])

pie(temp$n,labels = temp$rank1,col=ifelse(temp$rank1==4,2,3),main=("�ֺ� ��ȣ �׸�"))



table(MonCat_pc$periodc,MonCat_pc$Newsom)
table(MonCat_pc$volumec,MonCat_pc$Newsom)
table(MonCat_pc$rate1c,MonCat_pc$Newsom)
table(MonCat_pc$rate2c,MonCat_pc$Newsom)



table(MonCat_pc$Catprice1,MonCat_pc$Newsom)
table(MonCat_pc$Catprice2,MonCat_pc$Newsom)
table(MonCat_pc$Catprice3,MonCat_pc$Newsom)
table(MonCat_pc$Catprice4,MonCat_pc$Newsom)
table(MonCat_pc$Catprice5,MonCat_pc$Newsom)
table(MonCat_pc$Catprice6,MonCat_pc$Newsom)
table(MonCat_pc$Catprice7,MonCat_pc$Newsom)
table(MonCat_pc$Catprice11,MonCat_pc$Newsom)
table(MonCat_pc$Catprice12,MonCat_pc$Newsom)
table(MonCat_pc$Catprice13,MonCat_pc$Newsom)
table(MonCat_pc$Catprice14,MonCat_pc$Newsom)
table(MonCat_pc$Catprice15,MonCat_pc$Newsom)
table(MonCat_pc$Catprice16,MonCat_pc$Newsom)
table(MonCat_pc$Catprice17,MonCat_pc$Newsom)
table(MonCat_pc$Catprice18,MonCat_pc$Newsom)


aa<-MonCat_pc[MonCat_pc$key==11178,]
ggplot(MonCat_pc[MonCat_pc$Newsom==11,],aes(x=spend_all,y=..density..))+geom_histogram(color=1,fill="#F8766D")+xlim(c(0,3000000))+geom_vline(aes(xintercept=1113842),color="blue",size=2)+xlab("�� ���� �ݾ�")
ggplot(MonCat_pc[MonCat_pc$Newsom==11&MonCat_pc$rank1!=99,],aes(x=rank1,fill=ifelse(rank1==16,"F8766D","blue")))+geom_histogram(color=1,binwidth = 0.6)+xlab("�ֺ� ��ȣ �׸�")
pie(MonCat_pc[MonCat_pc$Newsom==11,]$rate1c)
temp<-MonCat_pc[MonCat_pc$Newsom==11,]%>%
  group_by(volumec)%>%
  summarise(n=n())
pie(temp$n[1:4],labels=paste(c("�ſ�����","����","�߰�","����"),round(temp$n/sum(temp$n)*100),"%"),main="�ŷ���",col=c("#FF9966","#FF9966","#FF9966","#0066CC"))
temp<-MonCat_pc[MonCat_pc$Newsom==11,]
##cluster�� ���� ��� ã�� 
unique_cluster <- unique(as.data.table(MonCat_rank[, c("key","Newsom")]))
ucluster<-unique_cluster%>%
  group_by(key)%>%
  summarise(n=n())

After<-MonCat_rank
After<-left_join(After,ucluster,by=("key"))

After1<-After[After$n>1,]
After2<-After[After$n==1,]
unique(After1$key)##16536�� 
unique(After2$key)##2796�� 


## ���� �м� ������ 
##��Ż�� 
##���� �̿�Ⱓ�� 2018�� 11�� ������ ���� ��� 
## �����̿��� 
## �����̿�Ⱓ�� 2018�� 11������ �̰� ���Ⱓ�� 3���� �̻��� ��� 
##�׿� 
## �����̿�Ⱓ�� 2018�� 11������ ������ ���Ⱓ�� 3���� �̸��� ����� �����̿��ڶ�� ���� ���ϹǷ� ����

exit<-personal[personal$late==201809&personal$start<=201807,]##999�� 
exit2<-personal[personal$late==201809&personal$start<=201804,]##999�� 
exit3<-personal[personal$late<201811,]
lasting<-personal[personal$late>201809&personal$start<=201807,] ##7411��3���� �̻� �����
lasting2<-personal[personal$late>201809&personal$start<=201804,] ##6901�� 6���� �̻� ����� 
lasting3<-personal[personal$period==13,]

##�׿� 300�� 
adata<-MonCat_pc%>%
  filter(key %in% unique(exit3$key))%>%
  mutate(A="exit")

Adata<-MonCat_pc%>%
  filter(key %in% unique(lasting3$key))%>%
  mutate(A="lasting")

bdata<-MonCat_pc%>%
  filter(key %in% unique(exit$key))%>%
  mutate(A="exit")

Bdata<-MonCat_pc%>%
  filter(key %in% unique(lasting$key))%>%
  mutate(A="lasting")

cdata<-MonCat_pc%>%
  filter(key %in% unique(exit2$key))%>%
  mutate(A="exit")

Cdata<-MonCat_pc%>%
  filter(key %in% unique(lasting2$key))%>%
  mutate(A="lasting")


data<-rbind(adata,Adata)##�������� ��Ż
data1<-rbind(bdata,Bdata)## ���ӱⰣ 3���� �̻�
data2<-rbind(cdata,Cdata)##���ӱⰣ 6���� �̻� 

temp<-data.frame(prop.table(table(data2$Newsom,data2$A),1))
ggplot(temp[1:15,],aes(x=Var1,fill=Var2))+geom_bar(aes(y=Freq),stat="identity")+ylim(0,1)+geom_hline(yintercept = 0.1,size=2)

ggplot(data1,aes(x=spendc,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(data1,aes(x=change,fill=,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(data1,aes(x=volumec,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)


ggplot(data2,aes(x=spendc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(data2,aes(x=change,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(data2,aes(x=volumec,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)



ggplot(data,aes(x=rate1c,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�Һ���� ��")
ggplot(data[data$A=="exit",],aes(x=period))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��(��Ż��)")
ggplot(data[data$A=="lasting",],aes(x=period))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��(��Ż��)")
ggplot(data,aes(x=period,fill=A))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��(��Ż��)")

ggplot(data2,aes(x=spendc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("����ݾ� ��")
ggplot(data2,aes(x=rate1c,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�Һ���� ��")
ggplot(data2,aes(x=volumec,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�ŷ��� ��")
ggplot(data2,aes(x=periodc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��")
ggplot(data2,aes(x=mono,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�Һ���� ��")


##som���� �������� ����� 
data<-data%>%
  group_by(key)%>%
  mutate(change=length(unique(Newsom)),periodn=period)%>%
  filter(SMS_REGISTRATION_MONTH==min(SMS_REGISTRATION_MONTH)|SMS_REGISTRATION_MONTH==max(SMS_REGISTRATION_MONTH))
temp<-prop.table(table(data$Newsom,data$A),1)
data$weight<-0
for(i in 1:15){
  data$weight<-ifelse(data$Newsom==i,temp[i,1],data$weight)
}


data1<-data1%>%
  group_by(key)%>%
  mutate(change=length(unique(Newsom)),periodn=period-(late-201809))%>%
  filter(SMS_REGISTRATION_MONTH==min(SMS_REGISTRATION_MONTH)|SMS_REGISTRATION_MONTH==max(SMS_REGISTRATION_MONTH))

temp<-prop.table(table(data1$Newsom,data1$A),1)
data1$weight<-0
for(i in 1:15){
  data1$weight<-ifelse(data1$Newsom==i,temp[i,1],data1$weight)
}


data2<-data2%>%
  group_by(key)%>%
  mutate(change=length(unique(Newsom)),periodn=period-(late-201809))%>%
  filter(SMS_REGISTRATION_MONTH==min(SMS_REGISTRATION_MONTH)|SMS_REGISTRATION_MONTH==max(SMS_REGISTRATION_MONTH))

temp<-prop.table(table(data2$Newsom,data2$A),1)
data2$weight<-0
for(i in 1:15){
  data2$weight<-ifelse(data2$Newsom==i,temp[i,1],data2$weight)
}




aa<-data1%>%
  group_by(key)%>%
  filter(period>1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[2],fvol=volume[1],lvol=volume[2],
            change=mean(change),period=mean(periodn),fsom=Newsom[1],lsom=Newsom[2],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[2],fcat=CAT[1],lcat=CAT[2],
            fr1=rate1[1],lr1=rate1[2],fr2=rate2[1],lr2=rate2[2],fr3=rate3[1],lr3=rate3[2],lweight=weight[1],fweight=weight[2])

bb<-data1%>%
  group_by(key)%>%
  filter(period==1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[1],fvol=volume[1],lvol=volume[1],
            change=mean(change),period=mean(periodn),fsom=Newsom[1],lsom=Newsom[1],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[1],fcat=CAT[1],lcat=CAT[1],
            fr1=rate1[1],lr1=rate1[1],fr2=rate2[1],lr2=rate2[1],fr3=rate3[1],lr3=rate3[1],lweight=weight[1],fweight=weight[1])



dat<-rbind(aa,bb)


dat<-dat%>%
  mutate(Y=ifelse(key%in% unique(exit$key),1,0))


ggplot(dat,aes(x=spendc,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(dat,aes(x=change,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(dat,aes(x=volumec,fill=YA,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)

table(dat$Y)
ext<-dat[dat$Y==1,]
lat<-dat[dat$Y==0,]

for(j in 2:4){
  for(i in 1:5){
    samp1<-sample(1:nrow(ext),round(nrow(ext)*(3/4),0))
    samp2<-sample(1:nrow(lat),nrow(ext)*j)
    lat2<-lat[samp2,]
    sampt<-sample(1:length(samp2),round(length(samp2)*(3/4),0))
    train<-rbind(ext[samp1,],lat2[sampt,])
    test<-rbind(ext[-samp1,],lat2[-sampt,])
    result<-test$Y
    test<-subset(test,select=-Y)
    table(result)
    
 
    
    model1<-glm(Y~start+period+change+fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+
                  fr1+lr1+fweight+lweight,data=train,family = "binomial")
    # model<-ctree(Y~period+fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+
    # fr1+lr1+fweight+lweight,data=train)
    model2<-randomForest(Y~start+period+change+fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+
                           fr1+lr1+fweight+lweight,data=train,ntree=800)
    varImpPlot(model2)
    
    pred1<-predict.glm(model1,test,type="response")
    pred2<-predict(model2,test,type="response")
    
    pred1<-ifelse(pred1>=0.5,1,0)
    pred2<-ifelse(pred2>=0.5,1,0)
    
    print(paste(j,":1 ","L.R is : ",sum(matrix(table(pred1,result))[c(1,4)])/sum(matrix(table(pred1,result))),sep=""))
    print(paste(j,":1 ","R.f is : ",sum(matrix(table(pred2,result))[c(1,4)])/sum(matrix(table(pred2,result))),sep=""))
    
    
  }
}




#data�� ���ؼ���
cc<-data%>%
  group_by(key)%>%
  filter(period>1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[2],fvol=volume[1],lvol=volume[2],
            change=mean(change),period=mean(periodn),fsom=Newsom[1],lsom=Newsom[2],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[2],fcat=CAT[1],lcat=CAT[2],
            fr1=rate1[1],lr1=rate1[2],fr2=rate2[1],lr2=rate2[2],fr3=rate3[1],lr3=rate3[2],lweight=weight[1],fweight=weight[2])

dd<-data%>%
  group_by(key)%>%
  filter(period==1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[1],fvol=volume[1],lvol=volume[1],
            change=mean(change),period=mean(periodn),fsom=Newsom[1],lsom=Newsom[1],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[1],fcat=CAT[1],lcat=CAT[1],
            fr1=rate1[1],lr1=rate1[1],fr2=rate2[1],lr2=rate2[1],fr3=rate3[1],lr3=rate3[1],lweight=weight[1],fweight=weight[1])



dat<-rbind(cc,dd)
dat<-dat%>%
  mutate(Y=ifelse(key%in% unique(exit3$key),1,0))

table(dat$Y)
ext<-dat[dat$Y==1,]
lat<-dat[dat$Y==0,]

for(i in 1:5){
  samp<-sample(1:16907,12680)
  train<-dat[samp,]
  test<-subset(dat[-samp,],select=-Y)
  result<-dat[-samp,]$Y
  table(result)
  
  model1<-glm(Y~fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+start+
                fr1+lr1+fweight+lweight,data=train,family = "binomial")
  # model<-ctree(Y~period+fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+
  # fr1+lr1+fweight+lweight,data=train)
  model2<-randomForest(Y~fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+start+
                         fr1+lr1+fweight+lweight,data=train,ntree=800)
  varImpPlot(model2)
  
  pred1<-predict.glm(model1,test,type="response")
  pred2<-predict(model2,test,type="response")
  
  pred1<-ifelse(pred1>=0.5,1,0)
  pred2<-ifelse(pred2>=0.5,1,0)
  
  print(paste("L.R is : ",sum(matrix(table(pred1,result))[c(1,4)])/sum(matrix(table(pred1,result))),sep=""))
  print(paste("R.f is : ",sum(matrix(table(pred2,result))[c(1,4)])/sum(matrix(table(pred2,result))),sep=""))
  
  
  
}






##���� ��� ���� ����ȭ 
som1<-som(scale(MonCat_rank[,c("spendc")]),somgrid(2,2,"rectangular")) ##�ݾ�(spend_all, spend1,spend2,spend3,spend4,spend5)
table(som1$unit.classif)
som2<-som(scale(MonCat_rank[,c("rank1","rank2","rank3","rank4","rank5")]),somgrid(3,1,"rectangular")) ## �׸�(rank1,rank2,rank3,rank4)
table(som2$unit.classif)
som3<-som(scale(MonCat_rank[,c("rate1c","rate2c","Juya","mono","volumec")]),somgrid(3,1,"rectangular")) ## rate1c ,juya,mono,CAT,volumec
table(som3$unit.classif)
km1<-kmeans(scale(MonCat_rank[,c("spendc")]),centers = 3)
table(km1$cluster)
km2<-kmeans(scale(MonCat_rank[,c("rank1","rank2","rank3","rank4","rank5")]),centers = 3)
table(km2$cluster)
km3<-kmeans(scale(MonCat_rank[,c("rate1c","rate2c","Juya","mono","volumec")]),centers = 3)
table(km3$cluster)

MonCat_rank$som1<-som1$unit.classif
MonCat_rank$som2<-som2$unit.classif
MonCat_rank$som3<-som3$unit.classif
MonCat_rank$som<-paste(MonCat_rank$som1,MonCat_rank$som2,MonCat_rank$som3,sep="")

MonCat_rank$km1<-km1$cluster
MonCat_rank$km2<-km2$cluster
MonCat_rank$km3<-km3$cluster
MonCat_rank$km<-paste(MonCat_rank$km1,MonCat_rank$km2,MonCat_rank$km3,sep="")



## som �����ϱ�� ���� 
##������ ������ �ʹ� ������� -> �� ����ȭ 
MonCat_rank$Newsom<-MonCat_rank$som
temp<-data.frame(table(MonCat_rank$Newsom))
colnames(temp)<-c("som","freq")
MonCat_rank<-left_join(MonCat_rank,temp,by="som")
MonCat_rank$Newsom<-ifelse(MonCat_rank$freq<1400,NA,MonCat_rank$Newsom)
# model<-randomForest(as.numeric(Newsom)~spendc+rank1+rank2+spend1+spend2+rate1+rate2+periodc+volumec+mono,data=MonCat_rank[is.na(MonCat_rank$Newsom)==F,],ntree=500)
# model<-ctree(as.numeric(Newsom)~spendc+rank1+rank2+spend1+spend2+rate1+rate2+periodc+volumec+mono,data=MonCat_rank[is.na(MonCat_rank$Newsom)==F,])
MonCat_rank$Newsom<-as.factor(MonCat_rank$Newsom)
MonCat_rank[,c("spendc","rank1","rank2","rank3","rank4","rank5","rate1c","rate2c","Juya","mono","volumec","som1","som2","som3","Newsom")]<-missForest(MonCat_rank[,c("spendc","rank1","rank2","rank3","rank4","rank5","rate1c","rate2c","Juya","mono","volumec","som1","som2","som3","Newsom")])$ximp

##�籺��ȭ Ȯ�� 
temp<-MonCat_rank[MonCat_rank$freq<1400,]
table(temp$som,temp$Newsom)
table(MonCat_rank$Newsom)





##KM �� 
table(MonCat_rank$km)
tapply(MonCat_rank$spend_all,MonCat_rank$km,mean)
tapply(MonCat_rank$spend1,MonCat_rank$km,mean)
tapply(MonCat_rank$spend2,MonCat_rank$km,mean)
tapply(MonCat_rank$spend3,MonCat_rank$km,mean)
tapply(MonCat_rank$spend4,MonCat_rank$km,mean)
tapply(MonCat_rank$spend5,MonCat_rank$km,mean)
tapply(MonCat_rank$rate1,MonCat_rank$km,mean)
tapply(MonCat_rank$rate2,MonCat_rank$km,mean)
tapply(MonCat_rank$rate3,MonCat_rank$km,mean)
tapply(MonCat_rank$rate4,MonCat_rank$km,mean)
tapply(MonCat_rank$rate5,MonCat_rank$km,mean)

table(MonCat_rank$rank1,MonCat_rank$km)
table(MonCat_rank$rank2,MonCat_rank$km)
table(MonCat_rank$rank3,MonCat_rank$km)
table(MonCat_rank$period,MonCat_rank$km)

table(MonCat_rank$gen,MonCat_rank$km)
table(MonCat_rank$GENDER,MonCat_rank$km)
table(MonCat_rank$Juya,MonCat_rank$km)
tapply(MonCat_rank$N,MonCat_rank$km,mean)
tapply(MonCat_rank$rank2,MonCat_rank$km,function(x){sum(x==99)})

tapply(MonCat_rank[MonCat_rank$rank2!=99,]$rank3,MonCat_rank[MonCat_rank$rank2!=99,]$km,function(x){sum(x==99)})
tapply(MonCat_rank[MonCat_rank$rank3!=99,]$rank4,MonCat_rank[MonCat_rank$rank3!=99,]$km,function(x){sum(x==99)})
tapply(MonCat_rank[MonCat_rank$rank4!=99,]$rank5,MonCat_rank[MonCat_rank$rank4!=99,]$km,function(x){sum(x==99)})

table(MonCat_rank$periodc,MonCat_rank$km)
table(MonCat_rank$volumec,MonCat_rank$km)
table(MonCat_rank$rate1c,MonCat_rank$km)
table(MonCat_rank$rate2c,MonCat_rank$km)
table(MonCat_rank$mono,MonCat_rank$km)
table(MonCat_rank$Y,MonCat_rank$km)

##SOM �� 
table(MonCat_rank$som1)
table(MonCat_rank$som2)
table(MonCat_rank$som3)
table(MonCat_rank$som)
table(MonCat_rank$Newsom)
tapply(MonCat_rank$spend_all,MonCat_rank$Newsom,mean)#
tapply(MonCat_rank$spendc,MonCat_rank$Newsom,mean)#
tapply(MonCat_rank$rate1,MonCat_rank$Newsom,mean)#
table(MonCat_rank$Juya,MonCat_rank$Newsom)#
table(MonCat_rank$rank1,MonCat_rank$Newsom)#
table(MonCat_rank$CAT,MonCat_rank$Newsom)#
table(MonCat_rank$mono,MonCat_rank$Newsom)#

table(MonCat_rank$gen,MonCat_rank$Newsom)
table(MonCat_rank$GENDER,MonCat_rank$Newsom)

table(MonCat_rank$periodc,MonCat_rank$Newsom)
table(MonCat_rank$volumec,MonCat_rank$Newsom)
table(MonCat_rank$rate1c,MonCat_rank$Newsom)
table(MonCat_rank$rate2c,MonCat_rank$Newsom)


table(MonCat_rank$Catprice1,MonCat_rank$Newsom)
table(MonCat_rank$Catprice2,MonCat_rank$Newsom)
table(MonCat_rank$Catprice3,MonCat_rank$Newsom)
table(MonCat_rank$Catprice4,MonCat_rank$Newsom)
table(MonCat_rank$Catprice5,MonCat_rank$Newsom)
table(MonCat_rank$Catprice6,MonCat_rank$Newsom)
table(MonCat_rank$Catprice7,MonCat_rank$Newsom)
table(MonCat_rank$Catprice11,MonCat_rank$Newsom)
table(MonCat_rank$Catprice12,MonCat_rank$Newsom)
table(MonCat_rank$Catprice13,MonCat_rank$Newsom)
table(MonCat_rank$Catprice14,MonCat_rank$Newsom)
table(MonCat_rank$Catprice15,MonCat_rank$Newsom)
table(MonCat_rank$Catprice16,MonCat_rank$Newsom)
table(MonCat_rank$Catprice17,MonCat_rank$Newsom)
table(MonCat_rank$Catprice18,MonCat_rank$Newsom)



##labeling cluster1 -> 1 �ʰ����/ 2�����  / 3  �����/ 4 �ߺ�� 
##labeling cluster2 -> 1 ������ �����ο� / 2 ��ſ� �߱�,������ �پ�  / 3 �ʼ�ǰ ���̻� ,  ������ �پ�
##labeling cluster3 -> 1     ���߱���       / 2 �ְ�   ����            /3   ��, ���� 
##cluster�� ���� ��� ã�� 
unique_cluster <- unique(as.data.table(MonCat_rank[, c("key","Newsom")]))
ucluster<-unique_cluster%>%
  group_by(key)%>%
  summarise(n=n())

After<-MonCat_rank
After<-left_join(After,ucluster,by=("key"))

After1<-After[After$n>1,]
After2<-After[After$n==1,]
unique(After1$key)##16536�� 
unique(After2$key)##2796�� 



## ���� �м� ������ 
##��Ż�� 
##���� �̿�Ⱓ�� 2018�� 11�� ������ ���� ��� 
## �����̿��� 
## �����̿�Ⱓ�� 2018�� 11������ �̰� ���Ⱓ�� 3���� �̻��� ��� 
##�׿� 
## �����̿�Ⱓ�� 2018�� 11������ ������ ���Ⱓ�� 3���� �̸��� ����� �����̿��ڶ�� ���� ���ϹǷ� ����

exit<-personal[personal$late==201809&personal$start<=201807,]##999�� 
exit2<-personal[personal$late==201809&personal$start<=201804,]##999�� 
exit3<-personal[personal$late<201811,]
lasting<-personal[personal$late>201809&personal$start<=201807,] ##7411��3���� �̻� �����
lasting2<-personal[personal$late>201809&personal$start<=201804,] ##6901�� 6���� �̻� ����� 
lasting3<-personal[personal$period==13,]

##�׿� 300�� 
adata<-MonCat_rank%>%
  filter(key %in% unique(exit3$key))%>%
  mutate(A="exit")

Adata<-MonCat_rank%>%
  filter(key %in% unique(lasting3$key))%>%
  mutate(A="lasting")

bdata<-MonCat_rank%>%
  filter(key %in% unique(exit$key))%>%
  mutate(A="exit")

Bdata<-MonCat_rank%>%
  filter(key %in% unique(lasting$key))%>%
  mutate(A="lasting")

cdata<-MonCat_rank%>%
  filter(key %in% unique(exit2$key))%>%
  mutate(A="exit")

Cdata<-MonCat_rank%>%
  filter(key %in% unique(lasting2$key))%>%
  mutate(A="lasting")


data<-rbind(adata,Adata)##�������� ��Ż
data1<-rbind(bdata,Bdata)## ���ӱⰣ 3���� �̻�
data2<-rbind(cdata,Cdata)##���ӱⰣ 6���� �̻� 

ggplot(data1,aes(x=spendc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("����ݾ� ��")
ggplot(data1,aes(x=rate1c,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�Һ���� ��")
ggplot(data1,aes(x=volumec,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�ŷ��� ��")
ggplot(data1,aes(x=period,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��")
ggplot(data1,aes(x=gen,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 1.5)+ggtitle("�̿�Ⱓ ��")
ggplot(data1,aes(x=som1,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��")




ggplot(data2,aes(x=spendc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("����ݾ� ��")
ggplot(data2,aes(x=change,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("���� ��ȭ Ƚ��")
ggplot(data2,aes(x=volumec,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�ŷ��� ��")
ggplot(data2,aes(x=periodc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��")



ggplot(data,aes(x=rate1c,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�Һ���� ��")
ggplot(data[data$A=="exit",],aes(x=period))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��(��Ż��)")
ggplot(data[data$A=="lasting",],aes(x=period))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��(��Ż��)")

ggplot(data2,aes(x=spendc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("����ݾ� ��")
ggplot(data2,aes(x=rate1c,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�Һ���� ��")
ggplot(data2,aes(x=volumec,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�ŷ��� ��")
ggplot(data2,aes(x=periodc,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�̿�Ⱓ ��")
ggplot(data2,aes(x=mono,fill=A,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)+ggtitle("�Һ���� ��")


##som���� �������� ����� 
data<-data%>%
  group_by(key)%>%
  mutate(change=length(unique(Newsom)),periodn=period)%>%
  filter(SMS_REGISTRATION_MONTH==min(SMS_REGISTRATION_MONTH)|SMS_REGISTRATION_MONTH==max(SMS_REGISTRATION_MONTH))
temp<-prop.table(table(data$Newsom,data$A),1)
data$weight<-0
for(i in 1:15){
  data$weight<-ifelse(data$Newsom==i,temp[i,1],data$weight)
}


data1<-data1%>%
  group_by(key)%>%
  mutate(change=length(unique(Newsom)),periodn=period-(late-201809))%>%
  filter(SMS_REGISTRATION_MONTH==min(SMS_REGISTRATION_MONTH)|SMS_REGISTRATION_MONTH==max(SMS_REGISTRATION_MONTH))

temp<-prop.table(table(data1$Newsom,data1$A),1)
data1$weight<-0
for(i in 1:15){
  data1$weight<-ifelse(data1$Newsom==i,temp[i,1],data1$weight)
}


data2<-data2%>%
  group_by(key)%>%
  mutate(change=length(unique(Newsom)),periodn=period-(late-201809))%>%
  filter(SMS_REGISTRATION_MONTH==min(SMS_REGISTRATION_MONTH)|SMS_REGISTRATION_MONTH==max(SMS_REGISTRATION_MONTH))

temp<-prop.table(table(data2$Newsom,data2$A),1)
data2$weight<-0
for(i in 1:15){
  data2$weight<-ifelse(data2$Newsom==i,temp[i,1],data2$weight)
}




aa<-data1%>%
  group_by(key)%>%
  filter(period>1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[2],fvol=volume[1],lvol=volume[2],
            change=mean(change),period=mean(periodn),fsom1=som1[1],lsom1=som1[2],fsom2=som2[1],lsom2=som2[2],fsom3=som3[1],lsom3=som3[2],
            fsom=Newsom[1],lsom=Newsom[2],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[2],fcat=CAT[1],lcat=CAT[2],
            fr1=rate1[1],lr1=rate1[2],fr2=rate2[1],lr2=rate2[2],fr3=rate3[1],lr3=rate3[2],lweight=weight[1],fweight=weight[2])

bb<-data1%>%
  group_by(key)%>%
  filter(period==1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[1],fvol=volume[1],lvol=volume[1],
            change=mean(change),period=mean(periodn),fsom1=som1[1],lsom1=som1[1],fsom2=som2[1],lsom2=som2[1],fsom3=som3[1],lsom3=som3[1],
            fsom=Newsom[1],lsom=Newsom[1],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[1],fcat=CAT[1],lcat=CAT[1],
            fr1=rate1[1],lr1=rate1[1],fr2=rate2[1],lr2=rate2[1],fr3=rate3[1],lr3=rate3[1],lweight=weight[1],fweight=weight[1])



dat<-rbind(aa,bb)


dat<-dat%>%
  mutate(Y=ifelse(key%in% unique(exit$key),1,0))


ggplot(dat,aes(x=spendc,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(dat,aes(x=change,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(dat,aes(x=volumec,fill=YA,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)

table(dat$Y)
ext<-dat[dat$Y==1,]
lat<-dat[dat$Y==0,]

for(j in 2:4){
  for(i in 1:5){
    samp1<-sample(1:nrow(ext),round(nrow(ext)*(3/4),0))
    samp2<-sample(1:nrow(lat),nrow(ext)*j)
    lat2<-lat[samp2,]
    sampt<-sample(1:length(samp2),round(length(samp2)*(3/4),0))
    train<-rbind(ext[samp1,],lat2[sampt,])
    test<-rbind(ext[-samp1,],lat2[-sampt,])
    result<-test$Y
    test<-subset(test,select=-Y)
    table(result)
    
    
    
    model1<-glm(Y~start+period+change+fspend+lspend+fvol+lvol+GENDER+gen+fsom1+lsom1+fsom2+lsom2+
                  fsom3+lsom3+fsom+lsom+fmono+lmono+fcat+lcat+
                  fr1+lr1+fweight+lweight,data=train,family = "binomial")
    # model<-ctree(Y~period+fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+
    # fr1+lr1+fweight+lweight,data=train)
    model2<-randomForest(Y~start+period+change+fspend+lspend+fvol+lvol+GENDER+gen+fsom1+lsom1+
                           fsom2+lsom2+fsom3+lsom3+fsom+lsom+fmono+lmono+fcat+lcat+
                           fr1+lr1+fweight+lweight,data=train,ntree=800)
    varImpPlot(model2)
    
    pred1<-predict.glm(model1,test,type="response")
    pred2<-predict(model2,test,type="response")
    
    pred1<-ifelse(pred1>=0.5,1,0)
    pred2<-ifelse(pred2>=0.5,1,0)
    
    print(paste(j,":1 ","L.R is : ",sum(matrix(table(pred1,result))[c(1,4)])/sum(matrix(table(pred1,result))),sep=""))
    print(paste(j,":1 ","R.f is : ",sum(matrix(table(pred2,result))[c(1,4)])/sum(matrix(table(pred2,result))),sep=""))
    
    
  }
}




#data�� ���ؼ���
cc<-data%>%
  group_by(key)%>%
  filter(period>1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[2],fvol=volume[1],lvol=volume[2],
            change=mean(change),period=mean(periodn),fsom1=som1[1],lsom1=som1[2],fsom2=som2[1],lsom2=som2[2],fsom3=som3[1],lsom3=som3[2],
            fsom=Newsom[1],lsom=Newsom[2],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[2],fcat=CAT[1],lcat=CAT[2],
            fr1=rate1[1],lr1=rate1[2],fr2=rate2[1],lr2=rate2[2],fr3=rate3[1],lr3=rate3[2],lweight=weight[1],fweight=weight[2])

dd<-data%>%
  group_by(key)%>%
  filter(period==1)%>%
  summarise(fspend=spend_all[1],lspend=spend_all[1],fvol=volume[1],lvol=volume[1],
            change=mean(change),period=mean(periodn),fsom1=som1[1],lsom1=som1[1],fsom2=som2[1],lsom2=som2[1],fsom3=som3[1],lsom3=som3[1],
            fsom=Newsom[1],lsom=Newsom[1],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[1],fcat=CAT[1],lcat=CAT[1],
            fr1=rate1[1],lr1=rate1[1],fr2=rate2[1],lr2=rate2[1],fr3=rate3[1],lr3=rate3[1],lweight=weight[1],fweight=weight[1])



dat<-rbind(cc,dd)
dat<-dat%>%
  mutate(Y=ifelse(key%in% unique(exit3$key),1,0))

table(dat$Y)
ext<-dat[dat$Y==1,]
lat<-dat[dat$Y==0,]

for(i in 1:5){
  samp<-sample(1:16907,12680)
  train<-dat[samp,]
  test<-subset(dat[-samp,],select=-Y)
  result<-dat[-samp,]$Y
  table(result)
  
  model1<-glm(Y~fspend+lspend+fvol+lvol+GENDER+gen+fsom1+lsom1+fsom2+lsom2+fsom3+lsom3+fsom+lsom+
                fmono+lmono+fcat+lcat+start+
                fr1+lr1+fweight+lweight,data=train,family = "binomial")
  # model<-ctree(Y~period+fspend+lspend+fvol+lvol+GENDER+gen+fsom+lsom+fmono+lmono+fcat+lcat+
  # fr1+lr1+fweight+lweight,data=train)
  model2<-randomForest(Y~fspend+lspend+fvol+lvol+GENDER+gen+fsom1+lsom1+fsom2+lsom2+fsom3+lsom3+
                         fsom+lsom+fmono+lmono+fcat+lcat+start+
                         fr1+lr1+fweight+lweight,data=train,ntree=800)
  varImpPlot(model2)
  
  pred1<-predict.glm(model1,test,type="response")
  pred2<-predict(model2,test,type="response")
  
  pred1<-ifelse(pred1>=0.5,1,0)
  pred2<-ifelse(pred2>=0.5,1,0)
  
  print(paste("L.R is : ",sum(matrix(table(pred1,result))[c(1,4)])/sum(matrix(table(pred1,result))),sep=""))
  print(paste("R.f is : ",sum(matrix(table(pred2,result))[c(1,4)])/sum(matrix(table(pred2,result))),sep=""))
  
  
  
}



##�׷��� �׸���� 


aa<-data1%>%
  group_by(key)%>%
  filter(period>1)%>%
  summarise(spendc=spendc[2],fspend=spend_all[1],lspend=spend_all[2],fvol=volume[1],lvol=volume[2],
            change=mean(change),period=mean(periodn),fsom=Newsom[1],lsom=Newsom[2],start=start[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[2],fcat=CAT[1],lcat=CAT[2],
            fr1=rate1[1],lr1=rate1[2],fr2=rate2[1],lr2=rate2[2],fr3=rate3[1],lr3=rate3[2],lweight=weight[1],fweight=weight[2])

bb<-data1%>%
  group_by(key)%>%
  filter(period==1)%>%
  summarise(spendc=spendc[1],fspend=spend_all[1],lspend=spend_all[1],fvol=volume[1],lvol=volume[1],
            change=mean(change),period=mean(periodn),fsom=Newsom[1],lsom=Newsom[1],
            GENDER=mean(GENDER),gen=mean(gen),fmono=mono[1],lmono=mono[1],fcat=CAT[1],lcat=CAT[1],
            fr1=rate1[1],lr1=rate1[1],fr2=rate2[1],lr2=rate2[1],fr3=rate3[1],lr3=rate3[1],lweight=weight[1],fweight=weight[1])



dat<-rbind(aa,bb)


dat<-dat%>%
  mutate(Y=ifelse(key%in% unique(exit$key),"exit","lasting"))

ggplot(dat,aes(x=spendc,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(dat,aes(x=change,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(dat,aes(x=lvol,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)
ggplot(dat,aes(x=start,fill=Y,y=..density..))+geom_histogram(position="dodge",binwidth = 0.5)














