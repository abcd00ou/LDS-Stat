rm(list=ls())
setwd("C:/Users/DAL/Desktop/Data/DLab_Sample_20181203sql")
library(data.table)
library(bit64)
options("scipen" = 1)
data1711<-data.frame(fread("201711.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1712<-data.frame(fread("201712.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1801<-data.frame(fread("201801.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1802<-data.frame(fread("201802.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1803<-data.frame(fread("201803.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1804<-data.frame(fread("201804.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1805<-data.frame(fread("201805.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1806<-data.frame(fread("201806.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1807<-data.frame(fread("201807.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1808<-data.frame(fread("201808.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1809<-data.frame(fread("201809.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1810<-data.frame(fread("201810.sql",sep2="|||",encoding = "UTF-8",quote=""))
data1811<-data.frame(fread("201811.sql",sep2="|||",encoding = "UTF-8",quote=""))
member<-data.frame(fread("MEMBER_INFO.sql",sep2="|||",encoding = "UTF-8",quote=""))


a<-seq(2,117,3)
b<-seq(3,118,3)
cnum<-c(a,b)
##�߸� ������� �� ���� 
data1711<-data1711[,-cnum]
data1712<-data1712[,-cnum]
data1801<-data1801[,-cnum]
data1802<-data1802[,-cnum]
data1803<-data1803[,-cnum]
data1804<-data1804[,-cnum]
data1805<-data1805[,-cnum]
data1806<-data1806[,-cnum]
data1807<-data1807[,-cnum]
data1808<-data1808[,-cnum]
data1809<-data1809[,-cnum]
data1810<-data1810[,-cnum]
data1811<-data1811[,-cnum]
member<-member[,-c(2,3,5,6)]


##CARD_MEMO ���� ������ ���� 
data1711<-data1711[,-c(32:40)]
data1712<-data1712[,-c(32:40)]
data1801<-data1801[,-c(32:40)]
data1802<-data1802[,-c(32:40)]
data1803<-data1803[,-c(32:40)]
data1804<-data1804[,-c(32:40)]
data1805<-data1805[,-c(32:40)]
data1806<-data1806[,-c(32:40)]
data1807<-data1807[,-c(32:40)]
data1808<-data1808[,-c(32:40)]
data1809<-data1809[,-c(32:40)]
data1810<-data1810[,-c(32:40)]
data1811<-data1811[,-c(32:40)]


##��� ���°� ����ġ ó�� 
data1711$LATITUDE[data1711$LATITUDE==""]<-NA
data1711$LONGITUDE[data1711$LONGITUDE==""]<-NA
data1711$ADDRESS[data1711$ADDRESS==""]<-NA
data1711$CARD_USER_NAME[data1711$CARD_USER_NAME==""]<-NA
data1711$CARD_NAME[data1711$CARD_NAME==""]<-NA

data1712$LATITUDE[data1712$LATITUDE==""]<-NA
data1712$LONGITUDE[data1712$LONGITUDE==""]<-NA
data1712$ADDRESS[data1712$ADDRESS==""]<-NA
data1712$CARD_USER_NAME[data1712$CARD_USER_NAME==""]<-NA
data1712$CARD_NAME[data1712$CARD_NAME==""]<-NA

data1801$LATITUDE[data1801$LATITUDE==""]<-NA
data1801$LONGITUDE[data1801$LONGITUDE==""]<-NA
data1801$ADDRESS[data1801$ADDRESS==""]<-NA
data1801$CARD_USER_NAME[data1801$CARD_USER_NAME==""]<-NA
data1801$CARD_NAME[data1801$CARD_NAME==""]<-NA

data1802$LATITUDE[data1802$LATITUDE==""]<-NA
data1802$LONGITUDE[data1802$LONGITUDE==""]<-NA
data1802$ADDRESS[data1802$ADDRESS==""]<-NA
data1802$CARD_USER_NAME[data1802$CARD_USER_NAME==""]<-NA
data1802$CARD_NAME[data1802$CARD_NAME==""]<-NA

data1803$LATITUDE[data1803$LATITUDE==""]<-NA
data1803$LONGITUDE[data1803$LONGITUDE==""]<-NA
data1803$ADDRESS[data1803$ADDRESS==""]<-NA
data1803$CARD_USER_NAME[data1803$CARD_USER_NAME==""]<-NA
data1803$CARD_NAME[data1803$CARD_NAME==""]<-NA

data1804$LATITUDE[data1804$LATITUDE==""]<-NA
data1804$LONGITUDE[data1804$LONGITUDE==""]<-NA
data1804$ADDRESS[data1804$ADDRESS==""]<-NA
data1804$CARD_USER_NAME[data1804$CARD_USER_NAME==""]<-NA
data1804$CARD_NAME[data1804$CARD_NAME==""]<-NA

data1805$LATITUDE[data1805$LATITUDE==""]<-NA
data1805$LONGITUDE[data1805$LONGITUDE==""]<-NA
data1805$ADDRESS[data1805$ADDRESS==""]<-NA
data1805$CARD_USER_NAME[data1805$CARD_USER_NAME==""]<-NA
data1805$CARD_NAME[data1805$CARD_NAME==""]<-NA

data1806$LATITUDE[data1806$LATITUDE==""]<-NA
data1806$LONGITUDE[data1806$LONGITUDE==""]<-NA
data1806$ADDRESS[data1806$ADDRESS==""]<-NA
data1806$CARD_USER_NAME[data1806$CARD_USER_NAME==""]<-NA
data1806$CARD_NAME[data1806$CARD_NAME==""]<-NA

data1807$LATITUDE[data1807$LATITUDE==""]<-NA
data1807$LONGITUDE[data1807$LONGITUDE==""]<-NA
data1807$ADDRESS[data1807$ADDRESS==""]<-NA
data1807$CARD_USER_NAME[data1807$CARD_USER_NAME==""]<-NA
data1807$CARD_NAME[data1807$CARD_NAME==""]<-NA

data1808$LATITUDE[data1808$LATITUDE==""]<-NA
data1808$LONGITUDE[data1808$LONGITUDE==""]<-NA
data1808$ADDRESS[data1808$ADDRESS==""]<-NA
data1808$CARD_USER_NAME[data1808$CARD_USER_NAME==""]<-NA
data1808$CARD_NAME[data1808$CARD_NAME==""]<-NA

data1809$LATITUDE[data1809$LATITUDE==""]<-NA
data1809$LONGITUDE[data1809$LONGITUDE==""]<-NA
data1809$ADDRESS[data1809$ADDRESS==""]<-NA
data1809$CARD_USER_NAME[data1809$CARD_USER_NAME==""]<-NA
data1809$CARD_NAME[data1809$CARD_NAME==""]<-NA

data1810$LATITUDE[data1810$LATITUDE==""]<-NA
data1810$LONGITUDE[data1810$LONGITUDE==""]<-NA
data1810$ADDRESS[data1810$ADDRESS==""]<-NA
data1810$CARD_USER_NAME[data1810$CARD_USER_NAME==""]<-NA
data1810$CARD_NAME[data1810$CARD_NAME==""]<-NA

data1811$LATITUDE[data1811$LATITUDE==""]<-NA
data1811$LONGITUDE[data1811$LONGITUDE==""]<-NA
data1811$ADDRESS[data1811$ADDRESS==""]<-NA
data1811$CARD_USER_NAME[data1811$CARD_USER_NAME==""]<-NA
data1811$CARD_NAME[data1811$CARD_NAME==""]<-NA


##USER_SIM_NUMBER �� RATING ���� (����ġ�� ��κ�)
data1711<-subset(data1711,select=-c(USER_SIM_NUMBER,RATING))
data1712<-subset(data1712,select=-c(USER_SIM_NUMBER,RATING))
data1801<-subset(data1801,select=-c(USER_SIM_NUMBER,RATING))
data1802<-subset(data1802,select=-c(USER_SIM_NUMBER,RATING))
data1803<-subset(data1803,select=-c(USER_SIM_NUMBER,RATING))
data1804<-subset(data1804,select=-c(USER_SIM_NUMBER,RATING))
data1805<-subset(data1805,select=-c(USER_SIM_NUMBER,RATING))
data1806<-subset(data1806,select=-c(USER_SIM_NUMBER,RATING))
data1807<-subset(data1807,select=-c(USER_SIM_NUMBER,RATING))
data1808<-subset(data1808,select=-c(USER_SIM_NUMBER,RATING))
data1809<-subset(data1809,select=-c(USER_SIM_NUMBER,RATING))
data1810<-subset(data1810,select=-c(USER_SIM_NUMBER,RATING))
data1811<-subset(data1811,select=-c(USER_SIM_NUMBER,RATING))


##data ���� 1711/1712,1801,1802 / 1803,1804,1805 / 1806,1807,1808 / 1809,1810,1811
##�� ���� ���� �ܿ�� �����Ͽ� ���� ���� 
data1<-data1711
data2<-rbind(data1712,data1801,data1802)
data3<-rbind(data1803,data1804,data1805)
data4<-rbind(data1806,data1807,data1808)
data5<-rbind(data1809,data1810,data1811)


## category code ��з� ����� 
data1$CATEGORY<-ifelse(data1$CATEGORY_CODE>1000,substr(data1$CATEGORY_CODE,1,2),substr(data1$CATEGORY_CODE,1,1))
data1$CATEGORY<-ifelse(data1$CATEGORY=="1","������",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="2","��Ʈ",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="3","Ŀ�ǵ���Ʈ",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="4","�ĺ�/�ܽ�",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="5","����",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="6","�м�/��Ƽ",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="7","����/�ڵ���",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="8","���",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="9","����",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="10","��ȭ/���",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="11","�Ƿ�/�ǰ�",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="12","�ְŻ�Ȱ",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="13","����/������",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="14","����",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="15","�ݷ�����",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="16","����",data1$CATEGORY)
data1$CATEGORY<-ifelse(data1$CATEGORY=="17","��Ÿ",data1$CATEGORY)

data2$CATEGORY<-ifelse(data2$CATEGORY_CODE>1000,substr(data2$CATEGORY_CODE,1,2),substr(data2$CATEGORY_CODE,1,1))
data2$CATEGORY<-ifelse(data2$CATEGORY=="1","������",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="2","��Ʈ",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="3","Ŀ�ǵ���Ʈ",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="4","�ĺ�/�ܽ�",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="5","����",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="6","�м�/��Ƽ",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="7","����/�ڵ���",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="8","���",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="9","����",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="10","��ȭ/���",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="11","�Ƿ�/�ǰ�",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="12","�ְŻ�Ȱ",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="13","����/������",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="14","����",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="15","�ݷ�����",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="16","����",data2$CATEGORY)
data2$CATEGORY<-ifelse(data2$CATEGORY=="17","��Ÿ",data2$CATEGORY)


data3$CATEGORY<-ifelse(data3$CATEGORY_CODE>1000,substr(data3$CATEGORY_CODE,1,2),substr(data3$CATEGORY_CODE,1,1))
data3$CATEGORY<-ifelse(data3$CATEGORY=="1","������",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="2","��Ʈ",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="3","Ŀ�ǵ���Ʈ",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="4","�ĺ�/�ܽ�",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="5","����",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="6","�м�/��Ƽ",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="7","����/�ڵ���",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="8","���",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="9","����",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="10","��ȭ/���",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="11","�Ƿ�/�ǰ�",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="12","�ְŻ�Ȱ",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="13","����/������",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="14","����",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="15","�ݷ�����",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="16","����",data3$CATEGORY)
data3$CATEGORY<-ifelse(data3$CATEGORY=="17","��Ÿ",data3$CATEGORY)


data4$CATEGORY<-ifelse(data4$CATEGORY_CODE>1000,substr(data4$CATEGORY_CODE,1,2),substr(data4$CATEGORY_CODE,1,1))
data4$CATEGORY<-ifelse(data4$CATEGORY=="1","������",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="2","��Ʈ",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="3","Ŀ�ǵ���Ʈ",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="4","�ĺ�/�ܽ�",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="5","����",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="6","�м�/��Ƽ",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="7","����/�ڵ���",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="8","���",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="9","����",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="10","��ȭ/���",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="11","�Ƿ�/�ǰ�",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="12","�ְŻ�Ȱ",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="13","����/������",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="14","����",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="15","�ݷ�����",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="16","����",data4$CATEGORY)
data4$CATEGORY<-ifelse(data4$CATEGORY=="17","��Ÿ",data4$CATEGORY)

data5$CATEGORY<-ifelse(data5$CATEGORY_CODE>1000,substr(data5$CATEGORY_CODE,1,2),substr(data5$CATEGORY_CODE,1,1))
data5$CATEGORY<-ifelse(data5$CATEGORY=="1","������",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="2","��Ʈ",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="3","Ŀ�ǵ���Ʈ",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="4","�ĺ�/�ܽ�",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="5","����",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="6","�м�/��Ƽ",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="7","����/�ڵ���",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="8","���",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="9","����",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="10","��ȭ/���",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="11","�Ƿ�/�ǰ�",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="12","�ְŻ�Ȱ",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="13","����/������",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="14","����",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="15","�ݷ�����",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="16","����",data5$CATEGORY)
data5$CATEGORY<-ifelse(data5$CATEGORY=="17","��Ÿ",data5$CATEGORY)

##�з� ��Ȯ�� �Ǵ� 
cat1<-data1[,c("CARD_APPROVAL_STORE","CATEGORY_CODE","CATEGORY")]
cat2<-data2[,c("CARD_APPROVAL_STORE","CATEGORY_CODE","CATEGORY")]
cat3<-data3[,c("CARD_APPROVAL_STORE","CATEGORY_CODE","CATEGORY")]
cat4<-data4[,c("CARD_APPROVAL_STORE","CATEGORY_CODE","CATEGORY")]
cat5<-data5[,c("CARD_APPROVAL_STORE","CATEGORY_CODE","CATEGORY")]

round(table(cat1$CATEGORY)/nrow(cat1),3)
round(table(cat2$CATEGORY)/nrow(cat2),3)
round(table(cat3$CATEGORY)/nrow(cat3),3)
round(table(cat4$CATEGORY)/nrow(cat4),3)
round(table(cat5$CATEGORY)/nrow(cat5),3)

##��Ȯ�� �ð� ������ 
data1$SMS_REG_DATE<-substr(data1$SMS_REGISTRATION_TIMESTAMP,5,8)
data1$SMS_REG_TIME<-substr(data1$SMS_REGISTRATION_TIMESTAMP,9,12)

data2$SMS_REG_DATE<-substr(data2$SMS_REGISTRATION_TIMESTAMP,5,8)
data2$SMS_REG_TIME<-substr(data2$SMS_REGISTRATION_TIMESTAMP,9,12)

data3$SMS_REG_DATE<-substr(data3$SMS_REGISTRATION_TIMESTAMP,5,8)
data3$SMS_REG_TIME<-substr(data3$SMS_REGISTRATION_TIMESTAMP,9,12)

data4$SMS_REG_DATE<-substr(data4$SMS_REGISTRATION_TIMESTAMP,5,8)
data4$SMS_REG_TIME<-substr(data4$SMS_REGISTRATION_TIMESTAMP,9,12)

data5$SMS_REG_DATE<-substr(data5$SMS_REGISTRATION_TIMESTAMP,5,8)
data5$SMS_REG_TIME<-substr(data5$SMS_REGISTRATION_TIMESTAMP,9,12)

# 
# ## ������¥�� ���γ�¥�� ���� �� 
# data1$difTime<-matrix(difftime(strptime(data1$CARD_APPROVAL_TIME,"%H%M"),strptime(data1$SMS_REG_TIME,"%H%M"),units="mins"),ncol=1)
# data1$difDay<-matrix(difftime(strptime(data1$CARD_APPROVAL_DATE,"%m%d"),strptime(data1$SMS_REG_DATE,"%m%d"),units="days"),ncol=1)
# 
# data2$difTime<-matrix(difftime(strptime(data2$CARD_APPROVAL_TIME,"%H%M"),strptime(data2$SMS_REG_TIME,"%H%M"),units="hours"),ncol=1)
# data2$difDay<-matrix(difftime(strptime(data2$CARD_APPROVAL_DATE,"%m%d"),strptime(data2$SMS_REG_DATE,"%m%d"),units="days"),ncol=1)
# 
# data3$difTime<-matrix(difftime(strptime(data3$CARD_APPROVAL_TIME,"%H%M"),strptime(data3$SMS_REG_TIME,"%H%M"),units="hours"),ncol=1)
# data3$difDay<-matrix(difftime(strptime(data3$CARD_APPROVAL_DATE,"%m%d"),strptime(data3$SMS_REG_DATE,"%m%d"),units="days"),ncol=1)
# 
# data4$difTime<-matrix(difftime(strptime(data4$CARD_APPROVAL_TIME,"%H%M"),strptime(data4$SMS_REG_TIME,"%H%M"),units="hours"),ncol=1)
# data4$difDay<-matrix(difftime(strptime(data4$CARD_APPROVAL_DATE,"%m%d"),strptime(data4$SMS_REG_DATE,"%m%d"),units="days"),ncol=1)
# 
# data5$difTime<-matrix(difftime(strptime(data5$CARD_APPROVAL_TIME,"%H%M"),strptime(data5$SMS_REG_TIME,"%H%M"),units="hours"),ncol=1)
# data5$difDay<-matrix(difftime(strptime(data5$CARD_APPROVAL_DATE,"%m%d"),strptime(data5$SMS_REG_DATE,"%m%d"),units="days"),ncol=1)


data1<-fread("data1.txt",sep="\t")
data2<-fread("data2.txt",sep="\t")
data3<-fread("data3.txt",sep="\t")
data4<-fread("data4.txt",sep="\t")
data5<-fread("data5.txt",sep="\t")




##unique key ����� 
uniqq<-unique(total$USER_ID)

data1$key<-0;data2$key<-0;data3$key<-0;data4$key<-0;data5$key<-0

for(i in 1:length(uniqq)){
  data1$key<-ifelse(data1$USER_ID==uniqq[i],i,data1$key)
}

for(i in 1:length(uniqq)){
  data2$key<-ifelse(data2$USER_ID==uniqq[i],i,data2$key)
}
for(i in 1:length(uniqq)){
  data3$key<-ifelse(data3$USER_ID==uniqq[i],i,data3$key)
}
for(i in 1:length(uniqq)){
  data4$key<-ifelse(data4$USER_ID==uniqq[i],i,data4$key)
}
for(i in 1:length(uniqq)){
  data5$key<-ifelse(data5$USER_ID==uniqq[i],i,data5$key)
}

member$key<-0
for(i in 1:length(uniqq)){
  member$key<-ifelse(member$USER_ID==uniqq[i],i,member$key)
}

total<-rbind(data1,data2,data3,data4,data5)

##��Ÿ �з� ���� ��Ȯ�ϰ� 
total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","�ĺ�/�ܽ�",total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","�ĺ�/�ܽ�",total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("��",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("��",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","�ĺ�/�ܽ�",total[grep("��",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","�ĺ�/�ܽ�",total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("�ܽ�",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("�ܽ�",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","�ĺ�/�ܽ�",total[grep("�ܽ�",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("�ĺ�",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("�ĺ�",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","�ĺ�/�ܽ�",total[grep("�ĺ�",total$CARD_APPROVAL_STORE),]$CATEGORY)

total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","����",total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("û��",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("û��",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","����",total[grep("û��",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","����",total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","����",total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY)
total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY<-ifelse(total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY=="��Ÿ","�ְŻ�Ȱ",total[grep("����",total$CARD_APPROVAL_STORE),]$CATEGORY)


total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="01","������",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="02","��Ʈ",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="03","Ŀ�ǵ���Ʈ",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="04","�ĺ�/�ܽ�",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="05","����",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="06","�м�/��Ƽ",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="07","����/�ڵ���",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="08","���",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="09","����",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="10","��ȭ/���",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="11","�Ƿ�/�ǰ�",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="12","�ְŻ�Ȱ",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="13","����/������",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="14","����",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="15","�ݷ�����",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="16","����",total$CATEGORY)
total$CATEGORY<-ifelse(total$CATEGORY=="��Ÿ"&total$IS_USER_CATEGORY=="Y"&substr(total$CATEGORY_CODE_USER,2,3)=="17","��Ÿ",total$CATEGORY)



total$CATEGORYN<-"00"
total$CATEGORYN<-ifelse(total$CATEGORY=="������","01",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="��Ʈ","02",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="Ŀ�ǵ���Ʈ","03",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="�ĺ�/�ܽ�","04",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="����","05",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="�м�/��Ƽ","06",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="����/�ڵ���","07",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="���","08",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="����","09",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="��ȭ/���","10",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="�Ƿ�/�ǰ�","11",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="�ְŻ�Ȱ","12",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="����/������","13",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="����","14",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="�ݷ�����","15",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="����","16",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="��Ÿ","17",total$CATEGORYN)
total$CATEGORYN<-ifelse(total$CATEGORY=="�Ա�","18",total$CATEGORYN)


##���Ӱ� ī�װ��� ���� 
total$NEWCAT<-ifelse(total$IS_USER_CATEGORY=="Y"&total$CATEGORY_CODE%/%100==17,substr(total$CATEGORY_CODE_USER,2,5),total$CATEGORY_CODE)
total$NEWCAT<-as.numeric(total$NEWCAT)

total$NEWCAT<-ifelse(total$NEWCAT==1201|total$NEWCAT==1203|total$NEWCAT==1204,1,total$NEWCAT)
temp<-total[total$NEWCAT>18,]
total$NEWCAT<-ifelse(total$NEWCAT==201|total$NEWCAT==202|total$NEWCAT==299|
                       total$NEWCAT==401,2,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT==504|total$NEWCAT==505|total$NEWCAT==599|total$NEWCAT==601,3,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT==701|total$NEWCAT==702|total$NEWCAT==704|total$NEWCAT==705,4,total$NEWCAT)
total$NEWCAT<-ifelse(total$CATEGORY=="���",5,total$NEWCAT)
total$NEWCAT<-ifelse(total$CATEGORY=="����",6,total$NEWCAT)
total$NEWCAT<-ifelse(total$CATEGORY=="�Ƿ�/�ǰ�",7,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT%/%100==17&total$CATEGORY=="�ĺ�/�ܽ�",2,total$NEWCAT)

total$NEWCAT<-ifelse(total$NEWCAT==1202|total$NEWCAT==1205|total$NEWCAT==1299,11,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT==101|total$NEWCAT==199|total$NEWCAT==301|
                       total$NEWCAT==399|total$NEWCAT==402|total$NEWCAT==499,12,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT==501|total$NEWCAT==502|total$NEWCAT==503|
                       total$NEWCAT==602|total$NEWCAT==699,13,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT==703|total$NEWCAT==706|total$NEWCAT==707|total$NEWCAT==799,14,total$NEWCAT)
total$NEWCAT<-ifelse(total$CATEGORY=="��ȭ/���",15,total$NEWCAT)
total$NEWCAT<-ifelse(total$CATEGORY=="����/������",16,total$NEWCAT)
total$NEWCAT<-ifelse(total$CATEGORY=="����",17,total$NEWCAT)
total$NEWCAT<-ifelse(total$CATEGORY=="�ݷ�����",18,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT>18&total$CATEGORY=="�ְŻ�Ȱ",1,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT>18&total$CATEGORY=="�ĺ�/�ܽ�",2,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT>18&total$CATEGORY=="����",19,total$NEWCAT)
total$NEWCAT<-ifelse(total$NEWCAT>18&total$CATEGORY=="��Ÿ",20,total$NEWCAT)


##������� ���� ���κ� �м� 
total$APPROVAL_PRICE_INOUT<-0
total$APPROVAL_PRICE_INOUT<-ifelse(total$CARD_APPROVAL_TYPE=="LD"|total$CARD_APPROVAL_TYPE=="FD"|total$CARD_APPROVAL_TYPE=="CD"|total$CARD_APPROVAL_TYPE=="MD",total$CARD_APPROVAL_REAL_PRICE,total$APPROVAL_PRICE_INOUT)
total$APPROVAL_PRICE_INOUT<-ifelse(total$CARD_APPROVAL_TYPE!="LD"&total$CARD_APPROVAL_TYPE!="FD"&total$CARD_APPROVAL_TYPE!="CD"&total$CARD_APPROVAL_TYPE!="MD",-total$CARD_APPROVAL_REAL_PRICE,total$APPROVAL_PRICE_INOUT)


##�ְ� �߰� �Һ��Ȱ 
total$hour<-total$SMS_REG_TIME%/%100
total$Juya<-ifelse(total$hour>6&total$hour<18,1,-1)


total<-total[total$CARD_APPROVAL_TYPE!="LC",]
total<-total[total$CARD_APPROVAL_TYPE!="FC",]
total<-total[(total$CARD_TYPE!="CCT"&total$CARD_TYPE!="CCK"),]


member<-data.frame(fread("member.txt",sep="\t"))
temp<-merge(total,member[,c(3,4,5,6)],by="key",all.x=T)


write.table(temp,"total.txt",sep="\t",row.names = F)
