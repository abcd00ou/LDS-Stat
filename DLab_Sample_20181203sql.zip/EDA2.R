rm(list=ls())
setwd("C:/Users/DAL/Desktop/Data/DLab_Sample_20181203sql")
library(data.table)
library(bit64)
library(ggmap)
library(dplyr)
library(ggplot2)

total<-data.frame(fread("total.txt",sep="\t"))
member<-data.frame(fread("member.txt",sep="\t"))

dup<-data.frame(matrix)
for(i in 1:19999){
  temp<-total[total$key==i,]
  dup<-rbind(dup,temp%>%
               filter(!duplicated(temp[,c("SMS_REG_DATE","SMS_REG_TIME","CARD_APPROVAL_REAL_PRICE")])))
  print(i)
  
}


nrow(total[total$key==1,])
nrow(dup[dup$key==1,])
write.table(dup,"dup.txt",sep="\t",row.names = F)

total<-total[total$CARD_APPROVAL_TYPE!="LC",]
total<-total[total$CARD_APPROVAL_TYPE!="FC",]

man<-total[total$GENDER==1,]
woman<-total[total$GENDER==2,]
t

##������� ���� ���κ� �м� 
total$APPROVAL_PRICE_INOUT<-0
total$APPROVAL_PRICE_INOUT<-ifelse(total$CARD_APPROVAL_TYPE=="LD"|total$CARD_APPROVAL_TYPE=="FD",total$CARD_APPROVAL_REAL_PRICE,total$APPROVAL_PRICE_INOUT)
total$APPROVAL_PRICE_INOUT<-ifelse(total$CARD_APPROVAL_TYPE!="LD"&total$CARD_APPROVAL_TYPE!="FD"&total$CARD_APPROVAL_TYPE!="����",-total$CARD_APPROVAL_REAL_PRICE,total$APPROVAL_PRICE_INOUT)
nrow(total[total$APPROVAL_PRICE_INOUT>0,])

temp1<-total%>%
  group_by(key,SMS_REGISTRATION_MONTH)%>%
  summarise(sum(APPROVAL_PRICE_INOUT[APPROVAL_PRICE_INOUT>=0]))

temp2<-total%>%
  group_by(key,SMS_REGISTRATION_MONTH)%>%
  summarise(sum(APPROVAL_PRICE_INOUT[APPROVAL_PRICE_INOUT<0]))
temp1<-data.frame(temp1);temp2<-data.frame(temp2)

Mon_Inc<-cbind(temp1,temp2[,3])




Cash<-total[total$COMPANY_NAME=="����",]
Card<-total[total$COMPANY_NAME!="����",]


## Card/Cash ī�� ��� �뵵 
sort(round(table(Cash$CATEGORY)/nrow(Cash),3),decreasing = T)
sort(round(table(Card$CATEGORY)/nrow(Card),3),decreasing = T)

sum(Cash$CARD_APPROVAL_REAL_PRICE)
sum(Card$CARD_APPROVAL_REAL_PRICE,na.rm=T)
unique(Cash$USER_ID)
unique(Card$USER_ID)


##Demographic �ۼ� 
for(i in seq(10,70,10)){
  for(j in c(1,2)){
    aa<-unique(total[total$GENDER==j&total$gen==i,]$key)
    print(j)
    print(i)
    print(length(aa))
  }
}

for(i in seq(10,70,10)){
  for(j in c(1,2)){
    aa<-sum(total[total$GENDER==j&total$gen==i,]$CARD_APPROVAL_REAL_PRICE,na.rm=T)
    print(j);print(i);print(aa/1000000)
   
  }
}

for(i in seq(10,70,10)){
  for(j in c(1,2)){
    aa<-mean(total[total$GENDER==j&total$gen==i,]$CARD_APPROVAL_REAL_PRICE,na.rm=T)
    print(j);print(i);print(aa)
    
  }
}

for(i in seq(10,70,10)){
  for(j in c(1,2)){
    aa<-mean(total[total$GENDER==j&total$gen==i,]$CARD_APPROVAL_REAL_PRICE,na.rm=T)
    print(j);print(i);print(aa)
    
  }
}

for(i in seq(10,70,10)){
  for(j in c(1,2)){
    aa<-sort(table(total[total$GENDER==j&total$gen==i,]$CATEGORY),decreasing=T)
    print(j);print(i)
    print(aa[1:5])
    
  }
}



#���κ� �м� 
unique_card <- unique(as.data.table(total[, c("key", "COMPANY_NAME")]))
personal<-data.frame(unique_card[, .N, by = "key"])
personal<-merge(personal,member[,c("key","gen","GENDER")],by="key",all.x=T)
personal$total_price<-c()

personal$total_price<-tapply(total$CARD_APPROVAL_REAL_PRICE,total$key,function(x){sum(x,na.rm=T)})

tapply(personal$N,personal[,c("gen","GENDER")],mean)
tapply(personal$N,personal[,c("gen","GENDER")],max)
tapply(personal$N,personal[,c("gen","GENDER")],min)
personal$amount<-tapply(total$SMS_ID,total$key,function(x){length(x)})
personal$maxCat1<-c()
personal$maxCat2<-c()
personal[,c("maxCat1","maxCat2")]<-matrix(unlist(tapply(total$CATEGORY,total$key,function(x){names(sort(table(x),decreasing=T)[1:2])})),ncol=2,byrow=T)

temp<-total%>%
      group_by(key)%>%
       summarise(start=min(SMS_REGISTRATION_MONTH),late=max(SMS_REGISTRATION_MONTH))
temp$dif<-temp$late-temp$start
temp$dif<-ifelse(temp$dif>10,temp$dif-87,temp$dif+1)
personal<-merge(personal,temp[,c("key","dif")],by="key",all.x=T)
personal$maxCat<-ifelse(personal$maxCat1=="��Ÿ",personal$maxCat2,personal$maxCat1)


temp<-total%>%
  group_by(key)%>%
  summarise(sum(APPROVAL_PRICE_INOUT))
personal<-merge(personal,temp,by="key")



temp<-personal[personal$dif>=7,]
table(temp$GENDER)
table(temp$gen)
table(personal$dif)

##������ ī���� ���� 
ggplot(personal,aes(x=N,fill=GENDER))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))

## ���ɺ� ī���� ���� 
ggplot(personal[personal$gen==10,],aes(x=N))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))
ggplot(personal[personal$gen==20,],aes(x=N))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))
ggplot(personal[personal$gen==30,],aes(x=N))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))
ggplot(personal[personal$gen==40,],aes(x=N))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))
ggplot(personal[personal$gen==50,],aes(x=N))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))
ggplot(personal[personal$gen==60,],aes(x=N))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))
ggplot(personal[personal$gen==70,],aes(x=N))+
  geom_histogram(binwidth = .5,position="dodge")+
  scale_x_continuous(breaks = c(1:26))


## ���κ� ��з� Ư�� 

table(personal$maxCat)
Cate<-table(personal$maxCat,personal$GENDER)
Cate<-data.frame(table(personal$maxCat,personal$GENDER))
Cate<-Cate[order(Cate$Freq,decreasing=T),]

ggplot(Cate,aes(x=Var1,y=Freq))+
  facet_grid(facets=.~Var2)+
  geom_bar(stat="identity")+
  geom_text(aes(y=Freq,label=(Freq/100)),size=3)

Cate2<-data.frame(table(personal$gen,personal$maxCat))
personal$av.tot<-round(personal$total_price/personal$dif,0)



##ī��纰 �м� 
comp<-data.frame(sort(table(total$COMPANY_NAME),decreasing=T)/nrow(total))
colnames(comp)<-c("COMPANY_NAME","RATE")
comp$RATE<-round(comp$RATE,4)
a<-total %>%
  group_by(COMPANY_NAME)%>%
  summarise(sum(CARD_APPROVAL_REAL_PRICE,na.rm=T))


comp<-merge(comp,a,by="COMPANY_NAME",all.x=T)
comp<-comp[order(comp$RATE,decreasing=T),]
sum(comp[19:86,]$`sum(CARD_APPROVAL_REAL_PRICE, na.rm = T)`)
comp$`sum(CARD_APPROVAL_REAL_PRICE, na.rm = T)`[1:18]
data.frame(sort(table(total$COMPANY_NAME),decreasing=T))

tab<-data.frame(unique_card[, .N, by = "COMPANY_NAME"])
comp<-merge(comp,tab,by="COMPANY_NAME")


name<-matrix(comp[order(comp$RATE,decreasing=T),]$COMPANY_NAME)

for(i in 1:18){
  temp<-total[total$COMPANY_NAME==name[i],]
  aa<-sort(table(temp$CATEGORY),decreasing = T)
  print(aa[1:5])
}


unique_card<-merge(unique_card,member,by="key",all.x=T)
aa<-table(unique_card$GENDER,unique_card$COMPANY_NAME)
colnames(aa)
rate<-cbind(colnames(aa),matrix(aa,ncol=2,byrow=T))
colnames(rate)<-c("COMPANY_NAME","1","2")
bb<-table(unique_card$gen,unique_card$COMPANY_NAME)

rate<-cbind(rate,matrix(bb,ncol=7,byrow=T))
rate<-data.frame(rate)
colnames(rate)<-c("COMPANY_NAME","1","2","10������","20��","30��","40��","50��","60��","70��")


comp2<-merge(comp,rate,by="COMPANY_NAME")
comp2[order(comp$RATE,decreasing=T),5:13]


## �췮������ �׿� 
High<-personal[personal$av.tot>100000000,]$key
MidH<-personal[personal$av.tot<100000000&personal$av.tot>10000000,]$key
MidM<-personal[personal$av.tot<10000000&personal$av.tot>1000000,]$key
MidL<-personal[personal$av.tot<1000000&personal$av.tot>500000,]$key
Low<-personal[personal$av.tot<500000,]$key
temp<-total[total$key==5,]





